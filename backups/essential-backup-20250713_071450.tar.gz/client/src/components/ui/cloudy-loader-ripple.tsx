import { useState } from 'react';
import cloudyMascot from '../../assets/cloudy-logo.png';
import cloudyWink from '../../assets/cloudy-wink.png';

interface CloudyLoaderRippleProps {
  className?: string;
}

export function CloudyLoaderRipple({ className = '' }: CloudyLoaderRippleProps) {
  const [cloudyLoaded, setCloudyLoaded] = useState(false);
  const [winkLoaded, setWinkLoaded] = useState(false);

  const imageStyle: React.CSSProperties = {
    transform: 'scale(0.9)',
    opacity: 1,
    visibility: (cloudyLoaded && winkLoaded ? 'visible' : 'hidden') as 'visible' | 'hidden',
    transition: 'none',
  };

  return (
    <div className={`fixed inset-0 flex-center ${className}`}>
      <div className="relative w-36 md:w-32 h-36 md:h-32 flex-center">
        <div className="absolute w-20 md:w-16 h-20 md:h-16 rounded-full bg-blue-400/20 animate-ripple-fast animation-delay-500"></div>
        <div className="absolute w-24 md:w-20 h-24 md:h-20 rounded-full bg-purple-400/20 animate-ripple-fast animation-delay-1000"></div>
        <div className="absolute w-28 md:w-24 h-28 md:h-24 rounded-full bg-indigo-400/20 animate-ripple-fast animation-delay-1500"></div>
        <div className="absolute w-32 md:w-28 h-32 md:h-28 rounded-full bg-cyan-400/20 animate-ripple-fast"></div>

        <img
          src={cloudyMascot}
          alt="Cloudy"
          className="w-24 md:w-20 h-24 md:h-20 object-contain cloudy-simple"
          style={imageStyle}
          onLoad={() => setCloudyLoaded(true)}
        />
        <img
          src={cloudyWink}
          alt="Cloudy Winking"
          className="w-24 md:w-20 h-24 md:h-20 object-contain absolute cloudy-simple-winking"
          style={imageStyle}
          onLoad={() => setWinkLoaded(true)}
        />
      </div>
    </div>
  );
}