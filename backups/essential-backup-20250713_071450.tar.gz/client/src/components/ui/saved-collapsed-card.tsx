import { Card, CardHeader } from '@/components/ui/card';
import { SavedCheckIcon } from '@/components/ui/saved-check-icon';
import { AlertTriangle, Clock, CheckIcon, ChevronDown } from 'lucide-react';

interface SavedCollapsedCardProps {
  sectionName: string;
  successMessage: string;
  summaryText: string;
  onExpand: () => void;
  // Visual indicator props for unsaved items
  hasUnsavedItems?: boolean;
  unsavedItemsType?: 'orange' | 'red'; // orange for inquiries, red for accounts/records
  unsavedItemsMessage?: string;
}

export function SavedCollapsedCard({
  sectionName,
  successMessage,
  summaryText,
  onExpand,
  hasUnsavedItems = false,
  unsavedItemsType = 'red',
  unsavedItemsMessage = '',
}: SavedCollapsedCardProps) {
  // Determine styling based on unsaved items
  const getCardStyling = () => {
    if (hasUnsavedItems) {
      return unsavedItemsType === 'orange' 
        ? 'bg-orange-50 border-2 border-orange-500 shadow-orange-200 shadow-lg' 
        : 'bg-red-50 border-2 border-red-500 shadow-red-200 shadow-lg';
    }
    return 'bg-green-50 border border-green-500';
  };

  const getHeaderStyling = () => {
    if (hasUnsavedItems) {
      return unsavedItemsType === 'orange' 
        ? 'cursor-pointer flex flex-row items-center p-6 bg-orange-50 hover:bg-orange-100 transition-colors duration-200' 
        : 'cursor-pointer flex flex-row items-center p-6 bg-red-50 hover:bg-red-100 transition-colors duration-200';
    }
    return 'cursor-pointer flex flex-row items-center p-6 bg-green-50 hover:bg-green-100 transition-colors duration-200';
  };

  const getTextColor = () => {
    if (hasUnsavedItems) {
      return unsavedItemsType === 'orange' ? 'text-orange-700' : 'text-red-700';
    }
    return 'text-green-700';
  };

  const getIconColor = () => {
    if (hasUnsavedItems) {
      return unsavedItemsType === 'orange' ? 'text-orange-600' : 'text-red-600';
    }
    return 'text-green-700';
  };

  return (
    <Card className={`${getCardStyling()} rounded-lg transition-all duration-300 hover:shadow-lg overflow-hidden`}>
      <CardHeader
        className={getHeaderStyling()}
        onClick={onExpand}
      >
        <div className="flex justify-between items-center w-full">
          <div className="flex items-center gap-3">
            {/* Icon based on state - EXACT CREDIT SUMMARY STRUCTURE */}
            {hasUnsavedItems ? (
              <div className={`w-8 h-8 rounded-full ${unsavedItemsType === 'orange' ? 'bg-orange-600' : 'bg-red-600'} flex items-center justify-center`}>
                {unsavedItemsType === 'orange' ? (
                  <Clock className="w-4 h-4 text-white" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-white" />
                )}
              </div>
            ) : (
              <div className="w-8 h-8 rounded-full bg-green-600 flex items-center justify-center text-white text-sm font-bold">
                <CheckIcon className="w-4 h-4" />
              </div>
            )}
            
            {/* Header text and summary */}
            <div>
              <h3 className={`text-lg font-bold ${getTextColor()}`}>
                {hasUnsavedItems ? (unsavedItemsType === 'orange' ? 'Items Remaining' : 'Action Required') : successMessage}
              </h3>
              <p className={`text-sm ${getTextColor()}`}>
                {hasUnsavedItems ? unsavedItemsMessage : summaryText}
              </p>
            </div>
          </div>
          
          {/* Expand indicator */}
          <div className="flex items-center gap-1">
            <span className={`text-sm ${getIconColor()}`}>
              {hasUnsavedItems ? 'Click to expand' : '3 Bureaus'}
            </span>
            <ChevronDown className={`w-4 h-4 ${getIconColor()}`} />
          </div>
        </div>
      </CardHeader>
    </Card>
  );
}