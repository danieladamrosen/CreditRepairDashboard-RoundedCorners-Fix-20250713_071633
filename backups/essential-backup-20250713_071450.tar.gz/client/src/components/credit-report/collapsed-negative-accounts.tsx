import { Card, CardHeader } from '@/components/ui/card';
import { ChevronDown, AlertTriangle } from 'lucide-react';

interface CollapsedNegativeAccountsProps {
  handleToggle: () => void;
  negativeAccounts: any[];
  negativeAccountsCollapsed: boolean;
}

export default function CollapsedNegativeAccounts({
  handleToggle,
  negativeAccounts,
  negativeAccountsCollapsed,
}: CollapsedNegativeAccountsProps) {
  return (
    <Card className="border-2 border-red-500 bg-red-50 rounded-lg hover:bg-red-100 hover:shadow-lg">
      <CardHeader
        onClick={handleToggle}
        className="flex flex-row items-center justify-between cursor-pointer"
      >
        <div className="flex flex-row items-center gap-2">
          <div className="bg-red-500 text-white text-sm font-bold rounded-full w-8 h-8 flex items-center justify-center">
            {negativeAccounts.length}
          </div>
          <div>
            <h3 className="text-lg font-bold text-red-700">
              Negative Accounts
            </h3>
            <p className="flex flex-row items-center gap-2 text-sm text-red-600">
              <AlertTriangle className="h-4 w-4" />
              {negativeAccounts.length} negative accounts need dispute review
            </p>
          </div>
        </div>
        <div className="flex flex-row items-center gap-2 text-sm font-bold text-red-600">
          {negativeAccounts.length} accounts
          <ChevronDown className="h-4 w-4 text-red-600" />
        </div>
      </CardHeader>
    </Card>
  );
}