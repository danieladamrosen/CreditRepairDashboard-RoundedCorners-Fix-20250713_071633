/**
 * Account utility functions shared across credit report components
 */

export interface Account {
  '@CreditLiabilityID'?: string;
  '@_AccountNumber'?: string;
  '@_AccountIdentifier'?: string;
  '@_SubscriberCode'?: string;
  '@_DerogatoryDataIndicator'?: string;
  '@IsCollectionIndicator'?: string;
  '@IsChargeoffIndicator'?: string;
  '@_PastDueAmount'?: string;
  '@_ChargeOffDate'?: string;
  '@_AccountClosedDate'?: string;
  '_CURRENT_RATING'?: { '@_Code'?: string };
  [key: string]: any;
}

/**
 * Determines if an account is considered negative based on multiple criteria
 */
export function isNegativeAccount(account: Account): boolean {
  // 1. Check derogatory data indicator
  if (account['@_DerogatoryDataIndicator'] === 'Y') {
    return true;
  }

  // 2. Check for collection accounts
  if (account['@IsCollectionIndicator'] === 'true' || account['@IsCollectionIndicator'] === 'Y') {
    return true;
  }

  // 3. Check for charge-off accounts
  if (account['@IsChargeoffIndicator'] === 'true' || account['@IsChargeoffIndicator'] === 'Y') {
    return true;
  }

  // 4. Check for past due amounts (indicates late payments)
  const pastDue = parseInt(account['@_PastDueAmount'] || '0');
  if (pastDue > 0) {
    return true;
  }

  // 5. Check current rating code for late payments (2-9 indicate late payments)
  const currentRating = account._CURRENT_RATING?.['@_Code'];
  if (currentRating && ['2', '3', '4', '5', '6', '7', '8', '9'].includes(currentRating)) {
    return true;
  }

  // 6. Check for charge-off date
  if (account['@_ChargeOffDate']) {
    return true;
  }

  return false;
}

/**
 * Determines if an account is closed based on various indicators
 */
export function isClosedAccount(account: Account): boolean {
  // Check if account has a closed date
  if (account['@_AccountClosedDate']) {
    return true;
  }

  // Check current rating codes that indicate closed accounts
  const currentRating = account._CURRENT_RATING?.['@_Code'];
  if (currentRating && ['C', 'X', 'D', 'F'].includes(currentRating)) {
    return true;
  }

  return false;
}

/**
 * Gets a unique identifier for an account
 */
export function getAccountId(account: Account): string {
  return (
    account['@CreditLiabilityID'] ||
    account['@_AccountNumber'] ||
    account['@_AccountIdentifier'] ||
    account['@_SubscriberCode'] ||
    'unknown'
  );
}

/**
 * Calculates the number of recent inquiries (within 24 months)
 */
export function calculateRecentInquiriesCount(inquiries: any[]): number {
  if (!Array.isArray(inquiries)) return 0;
  
  const cutoffDate = new Date();
  cutoffDate.setMonth(cutoffDate.getMonth() - 24);
  
  return inquiries.filter(inquiry => {
    const inquiryDate = new Date(inquiry['@_InquiryDate'] || inquiry.date);
    return inquiryDate >= cutoffDate;
  }).length;
}

/**
 * Gets the display status for an inquiry
 */
export function getInquiryStatusText(inquiry: any): string {
  const inquiryDate = new Date(inquiry['@_InquiryDate'] || inquiry.date);
  const cutoffDate = new Date();
  cutoffDate.setMonth(cutoffDate.getMonth() - 24);
  
  return inquiryDate >= cutoffDate ? 'Recent' : 'Older';
}

/**
 * Filters accounts by type (negative, positive, closed)
 */
export function filterAccountsByType(accounts: Account[], type: 'negative' | 'positive' | 'closed'): Account[] {
  if (!Array.isArray(accounts)) return [];
  
  return accounts.filter(account => {
    switch (type) {
      case 'negative':
        return isNegativeAccount(account);
      case 'positive':
        return !isNegativeAccount(account) && !isClosedAccount(account);
      case 'closed':
        return isClosedAccount(account);
      default:
        return false;
    }
  });
}

/**
 * Gets account status for display purposes
 */
export function getAccountStatus(account: Account): string {
  if (isNegativeAccount(account)) {
    return 'negative';
  }
  if (isClosedAccount(account)) {
    return 'closed';
  }
  return 'positive';
}